<!DOCTYPE html>
<html>
<head>
	<title>Email Confirmation</title>
</head>
<body>
	<?php

	include("config.php");

	//table name
	//$tbl_name = temp_members_db;

	//Random Confirmation Code
	$confirm_code = md5(uniqid(rand()));

	//values sent from form
	$name = $_POST['name'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	$country = $_POST['country'];

	//Insert data into database
	$sql = "INSERT INTO temp_members_db(confirm_code,name,email,password,country)VALUES('$confirm_code','$name','$email','$password','$country')";
	$result = mysql_query($sql);

	/*//if sucessfully inserted data into database,send confirmation linl to email
	if($result){

		// send email to...
		$to = $email;

		//your subject
		$subject = "Your confirmation link here";

		//from
		$header = "from:your name <your email>";

		//your message
		$message="Your Comfirmation link \r\n";
		$message.="Click on this link to activate your account \r\n";
		$message.="http://www.yourweb.com/confirmation.php?passkey=$confirm_code";

		//send email
		$sentmail = mail($to,$subject,$message,$header);


	} 
		//if not found
	else {
		echo "Not found your email in our database";
	}

		//if your email successfully sent
	if($sentmail){
		echo "Your Confirmation link has been sent to your email address.";
	} else {
		echo "Cannot sent Confirmation link to your email address";
	}*/

?>
	<p>Please click link <a href="confirmation.php?passkey=<?php echo $confirm_code ?>">Activate your account</a></p>
</body>
</html>