<?php
	include("config.php");

	//passkey that got from link
	$passkey = $_GET['passkey'];
	$tbl_name1 = "temp_members_db";

	//retrieve data from table where row that match this passkey
	$sql1 = "SELECT * FROM $tbl_name1 WHERE confirm_code='$passkey'";
	$result1 = mysql_query($sql1);

	//if successfully queried
	if($result1){

		//count how many row has this passkey
		$count = mysql_num_rows($result1);

		//if found this passkey in our database,retrieve data from table "temp_members_db"
		if($count==1){

			$rows=mysql_fetch_array($result1);
			$name=$rows['name'];
			$email=$rows['email'];
			$password=$rows['password'];
			$country=$rows['country'];
			$tbl_name2="registered_members";

			// Insert data that retrieves from "temp_members_db" into table "registered_members" 
			$sql2="INSERT INTO $tbl_name2(name, email, password, country)VALUES('$name', '$email', '$password', '$country')";
			$result2=mysql_query($sql2);
		}
		//if not found passkey,display message"wrong confirmation code
		else {
			echo "Wrong Confirmation Code";
		}

		// if successfully moved data from table"temp_members_db" to table "registered_members" displays message "Your account has been activated" and don't forget to delete confirmation code from table "temp_members_db"
		if($result2){
			echo "Your account has been activated";

			// Delete information of this user from table "temp_members_db" that has this passkey 
			$sql3="DELETE FROM $tbl_name1 WHERE confirm_code='$passkey'";
			$result3=mysql_query($sql3);
		}
	}
?>